const SERIAL_PORT = "/dev/LACHONG";
 

let ID_CONG_TY = "-1";


const TYPE_PORT_CONFIG = {
    TCP: 1,
    COM: 2
}

const CONFIG_PORT = {

	1: {
        id: 1,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    }, 
    2: {
        id: 2,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    }, 
    3: {
        id: 3,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	4: {
        id: 4,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	5: {
        id: 5,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	6: {
        id: 6,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	7: {
        id: 7,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    }, 
    8: {
        id: 8,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    }, 
    9: {
        id: 9,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	10: {
        id: 10,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	11: {
        id: 11,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    },
	12: {
        id: 12,
        com: SERIAL_PORT,
        ip: '127.0.0.1',
        portTCP: 8086,
        type: TYPE_PORT_CONFIG.TCP
    }
	
};


	
// xu ly neu CONFIG PORT TCP K CO COM
Object.keys(CONFIG_PORT).forEach(key => {
    if (CONFIG_PORT[key].type === TYPE_PORT_CONFIG.TCP) {
        CONFIG_PORT[key].com = CONFIG_PORT[key].ip+CONFIG_PORT[key].portTCP;
    }
});

 
const CONFIG_DATABASE = {
    server: "localhost",
    database: "",
    user: "",
    password: "",
    port: 1433,
    options: {
        "encrypt": true
    },
    pool: {
        "max": 200,
        "min": 20,
        "idleTimeoutMillis": 30000
    },
    connectionTimeout: 300000,
    requestTimeout: 300000,
};


const CONFIG_METRO = {
    0: "Not SET",
    1: "DO",
    2: "E5",
    3: "A95"
};

function getMetroName(id) {
    if (+id === +id)
        return CONFIG_METRO[id] || "";
    return CONFIG_METRO
}


function getIDCT() {
    return ID_CONG_TY;
   
}

function setIDCT(IDCT) {
    ID_CONG_TY = IDCT;
   
}



function getCOM() {
    return SERIAL_PORT;
   
}


function getAllPortConnect() {
    let arr = []
    Object.values(CONFIG_PORT).forEach(i => {
        /*if (!arr.includes(i.com.toUpperCase())) {
            arr.push(i.com.toUpperCase());
        }*/
				
		if (!arr.includes(i.com)) {
            arr.push(i.com);
        }
		
		
    });
    return arr;
}

function getComNameFromId(id) {
    return CONFIG_PORT[id];
}

function isPump(id) {
    return Boolean(CONFIG_PORT[id])
}

function getAllPump(type = 'arr') {
    if (type !== 'arr')
        return CONFIG_PORT;
    return Object.values(CONFIG_PORT);
}

module.exports = {
   getCOM, setIDCT,getIDCT, getAllPump, getAllPortConnect, isPump, getMetroName, CONFIG_DATABASE, TYPE_PORT_CONFIG,getComNameFromId
}