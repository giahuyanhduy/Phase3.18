// Import events module
const events = require('events');
// Create an EventEmitter object
const eventEmitter = new events.EventEmitter();
module.exports = eventEmitter;