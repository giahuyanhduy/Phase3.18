//
// function insertLastMaBom(idcot, com, pos = 0) {
//     utils.writeLog("Bat dau lay ma bom cot ", idcot);
//     GAS.sendCommand([CMD.STX, 0, idcot, CMD.cmdRDP, ...numberToByteArray(pos), 12], com, (err, data) => {
//         let isComplete = false;
//         if (data && data[3] !== 78 && data.length == 18) {
//             utils.writeLog("data lay ma bom cot ", idcot, data)
//             let dateBin = bytesToInt(getSubArray(data, 4, 4));
//             let money = bytesToInt(getSubArray(data, 8, 4));
//             let mili = bytesToInt(getSubArray(data, 12, 4));
//             let second = dateBin & 0x3f;
//             let minute = dateBin >> 6 & 0x3f;
//             let hour = dateBin >> 12 & 0x1f;
//             let day = dateBin >> 17 & 0x1f;
//             let month = dateBin >> 22 & 0x0f;
//             let year = dateBin >> 26 & 0x3f;
//             let date = new Date(year + 2000, month - 1, day, hour, minute, second);
//             isComplete = true;
//             if (year > 18) {
//                 let obj = {idcot, money, mili, date, pump: GAS_DATA[idcot].pump, pos}
//                 Helper.insertMaBom(obj, (err, data) => {
//                     utils.writeLog("#mabommoi", obj)
//                 });
//             }
//         }
//         if (!isComplete) {
//             insertLastMaBom(idcot, com, pos);
//         }
//     });
// }
// function getArrSend(arr) {
//     const ID_PUMP = arr[2];
//     arr[1] = arr.length + 2;//cnt
//     arr.push(1);
//     let checksum = (0 - arr.reduce((a, b) => a + b, 0)) & 0xff;
//     arr.push(checksum);
//     return arr;
// }
let a = [1, 16, 3, 4, 5, 6, 7, 8, 9, 0, 10, 11, 12, 39, 43, 12312, 1231, 1212321, 121, 11213, 6556, 43, 534, 124]
a.splice(0, a.indexOf(16));
console.log(a, a.indexOf(10))
